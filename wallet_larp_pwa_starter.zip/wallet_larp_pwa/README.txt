# Wallet LARP PWA starter

This is a fictional wallet UI for personal demo/role-play use. All cards and payment results are simulated.

## Files
- `index.html`: app interface
- `manifest.webmanifest`: install metadata
- `sw.js`: offline cache
- `icon-192.png`, `icon-512.png`: Home Screen icons

## Run locally
PWA installation and service workers require HTTPS or localhost. Opening `index.html` directly from Files will show the UI but will not enable full PWA installation/offline support.

## Publish
Upload all files to a static host that serves HTTPS (for example GitHub Pages or Netlify). Keep all files in the same published folder.

## Add to iPhone
1. Open the published HTTPS address in Safari.
2. Tap Share.
3. Choose Add to Home Screen.
4. Confirm the name and tap Add.

No real cards, credentials, Face ID, or payments are used.
